-- partial dump
CREATE TABLE wp_users (ID bigint);
